The Gangs Modpack v0.1.42 server update

Stop the server before applying this update.

Copy mods-to-copy/goldclaim-1.0.8.jar into the server mods folder and remove the old goldclaim-1.0.7.jar.

Start the server normally. A full restart is required for the new GoldClaim code to load.

After restarting, claim owners can use:
/claim trust interact <player>

This allows the trusted player to use non-inventory blocks such as Waystones, doors, buttons, and levers. It does not allow breaking or placing blocks or accessing chests and other inventories.
