package com.github.alexmodguy.alexscaves.mixin.client;

import com.github.alexmodguy.alexscaves.client.model.bridge.BasicEntityModelMethod2819;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;

import java.lang.reflect.Method;

@Pseudo
@Mixin(targets = "com.github.alexthe666.citadel.client.model.basic.BasicEntityModel")
@Implements(@Interface(iface = BasicEntityModelMethod2819.class, prefix = "ac$"))
@Environment(EnvType.CLIENT)
public abstract class MixinBasicEntityModel<T extends Entity> implements BasicEntityModelMethod2819 {
    @Unique
    private Method ac$setupAnimMethod;

    @SuppressWarnings("unchecked")
    public void method_2819(Entity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.ac$method_2819((Object) entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
    }

    @Unique
    @SuppressWarnings("unchecked")
    public void ac$method_2819(Object entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        if (entity == null) {
            return;
        }
        try {
            if (ac$setupAnimMethod == null) {
                for (Method method : this.getClass().getMethods()) {
                    if (!method.getName().equals("setupAnim") || method.getParameterCount() != 6) {
                        continue;
                    }
                    Class<?>[] params = method.getParameterTypes();
                    if (params[0].isAssignableFrom(entity.getClass())
                            && params[1] == float.class
                            && params[2] == float.class
                            && params[3] == float.class
                            && params[4] == float.class
                            && params[5] == float.class) {
                        ac$setupAnimMethod = method;
                        ac$setupAnimMethod.setAccessible(true);
                        break;
                    }
                }
            }
            if (ac$setupAnimMethod != null) {
                ac$setupAnimMethod.invoke(this, entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
            }
        } catch (ReflectiveOperationException ignored) {
        }
    }
}