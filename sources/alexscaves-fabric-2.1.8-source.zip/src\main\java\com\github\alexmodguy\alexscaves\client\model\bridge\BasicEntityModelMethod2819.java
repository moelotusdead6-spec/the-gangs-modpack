package com.github.alexmodguy.alexscaves.client.model.bridge;

public interface BasicEntityModelMethod2819 {
    void method_2819(Object entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch);
}