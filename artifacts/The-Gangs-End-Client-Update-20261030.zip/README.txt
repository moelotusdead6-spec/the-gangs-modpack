The Gangs Modded Adventure - End library update (2026-10-30)

Close Minecraft before updating this Prism instance.
In Edit Instance > Mods, remove or disable these old files:
  bclib-3.0.14.jar
  better-end-4.0.11.jar
Add the two jars from this archive's mods folder:
  bclib-3.0.16.jar
  better-end-4.0.12.jar
Do not leave both old and new copies enabled.
No worlds, personal options, resource packs, or other mods need replacing.

These are unmodified official Fabric 1.20.1 releases:
BCLib 3.0.16: https://modrinth.com/mod/bclib/version/SF3ws3Yh
Better End 4.0.12: https://modrinth.com/mod/betterend/version/KxnyNtqr
Project licenses and corresponding upstream source are linked on those pages.

The server update also contains GoldClaim 1.0.62 for command suggestions,
double sponge absorption, and shattered dimensional portal border limits.
GoldClaim is server-only and must not be added to clients.
Apply these client library updates before joining after the server restart.
