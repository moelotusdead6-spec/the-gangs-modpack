# v1.1.17 Neon Wall Wonders

Neon Wall Wonders **8.0.0** adds 60 glowing wall signs to Fabric 1.20.1.
It requires Java 17+, Fabric Loader 0.16.14+ and Fabric API, already supplied
by this pack. Install the same jar on server and clients.

## Clients

Close Minecraft and press Play in the existing auto-updating Prism instance.
Packwiz downloads the original jar and verifies its SHA-256. Do not create a
replacement instance. For clients without automatic updates, enable them
using the [update guide](README.md), or extract this release's update ZIP
and copy its `mods` contents into the existing instance's `minecraft/mods`
directory. The ZIP preserves the original jar's filename.
Keep only one enabled Neon Wall Wonders jar.

## Server

Place the original jar in `/home/container/mods` for the next normal restart.
Do not change the existing Fabric startup launcher or other pending updates.
Uploading does not load the mod into the running game. No restart, reload
or console command is part of staging.

Original filename: `neon-wall-wonders-gwbzt3mk (10).jar`.
SHA-256: `a0b36248530bfcbc398167b8cb7cade47d494053167822f33d2abe17d42158cc`.
The download's `(10)` suffix is not the mod version.

## Attribution and license

Created by oux_y using [CreativeMode.net](https://creativemode.net).
[Official mod page](https://creativemode.net/mod/neon-wall-wonders-gwbzt3mk).
[CreativeMode Mods License](https://creativemode.net/mod-license).
The original, unmodified file is shared free of charge with its original
filename, embedded license and attribution notices preserved.
Do not redistribute a renamed or modified jar, include it in paid packs,
or require payment, subscription or donation for server access.
The jar includes CreativeMode's telemetry module; its embedded license
describes optional analytics and the settings opt-out.

## Rollback

Before the next restart, remove only this jar from the server's mods folder.
After activation, stop the server and back up the world before removing it;
placed signs and stored mod items may be lost when the mod is removed.
Remove the Packwiz entry and republish the index before clients relaunch,
then remove any unmanaged copies from their mods folder. Leave all other
mods and the existing startup launcher unchanged.
