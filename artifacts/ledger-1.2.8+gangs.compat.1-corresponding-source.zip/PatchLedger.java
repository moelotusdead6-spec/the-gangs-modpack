import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Reproducible LGPL-3.0 Ledger 1.2.8 compatibility patch; no database/schema changes. */
public final class PatchLedger implements Opcodes {
    static final String DB = "com/github/quiltservertools/ledger/database/DatabaseManager";
    static final String WORLD_DESC = "(Lorg/jetbrains/exposed/sql/Transaction;Lnet/minecraft/class_2960;)Lcom/github/quiltservertools/ledger/database/Tables$World;";
    static int worlds, durations;

    static byte[] patch(byte[] bytes) {
        ClassNode c = new ClassNode();
        new ClassReader(bytes).accept(c, 0);
        boolean changed = false;
        if (c.name.equals(DB)) {
            MethodNode find = c.methods.stream().filter(m -> m.name.equals("selectWorld") && m.desc.equals(WORLD_DESC)).findFirst().orElseThrow();
            find.name = "ledgerRepairFindWorld";
            int replaced = 0;
            for (AbstractInsnNode n : find.instructions) {
                if (n instanceof MethodInsnNode m && m.owner.equals("kotlin/collections/CollectionsKt") && m.name.equals("first")) {
                    m.name = "firstOrNull";
                    replaced++;
                }
            }
            if (replaced != 1) throw new IllegalStateException("Unexpected world lookup");
            MethodNode wrapper = new MethodNode(ACC_PRIVATE | ACC_FINAL, "selectWorld", WORLD_DESC, null, null);
            wrapper.visitVarInsn(ALOAD, 0);
            wrapper.visitVarInsn(ALOAD, 1);
            wrapper.visitVarInsn(ALOAD, 2);
            wrapper.visitMethodInsn(INVOKESPECIAL, DB, find.name, find.desc, false);
            wrapper.visitInsn(DUP);
            Label found = new Label();
            wrapper.visitJumpInsn(IFNONNULL, found);
            wrapper.visitInsn(POP);
            wrapper.visitVarInsn(ALOAD, 0);
            wrapper.visitVarInsn(ALOAD, 1);
            wrapper.visitVarInsn(ALOAD, 2);
            wrapper.visitMethodInsn(INVOKESPECIAL, DB, "insertWorld", "(Lorg/jetbrains/exposed/sql/Transaction;Lnet/minecraft/class_2960;)V", false);
            wrapper.visitVarInsn(ALOAD, 0);
            wrapper.visitVarInsn(ALOAD, 1);
            wrapper.visitVarInsn(ALOAD, 2);
            wrapper.visitMethodInsn(INVOKESPECIAL, DB, find.name, find.desc, false);
            wrapper.visitInsn(DUP);
            wrapper.visitMethodInsn(INVOKESTATIC, "kotlin/jvm/internal/Intrinsics", "checkNotNull", "(Ljava/lang/Object;)V", false);
            wrapper.visitLabel(found);
            wrapper.visitInsn(ARETURN);
            wrapper.visitMaxs(3, 3);
            wrapper.visitEnd();
            c.methods.add(wrapper);
            worlds++;
            changed = true;
        }
        for (MethodNode m : c.methods) {
            for (AbstractInsnNode n : m.instructions.toArray()) {
                if (!(n instanceof MethodInsnNode call) || !call.owner.equals("kotlin/time/Duration$Companion")) continue;
                String unit = switch (call.name) {
                    case "minutes-UwyO8pc" -> "MINUTES";
                    case "seconds-UwyO8pc" -> "SECONDS";
                    default -> null;
                };
                if (unit == null || !call.desc.equals("(J)J")) continue;
                AbstractInsnNode previous = call.getPrevious();
                while (previous != null && !(previous instanceof FieldInsnNode f && f.getOpcode() == GETSTATIC && f.owner.equals("kotlin/time/Duration") && f.name.equals("Companion"))) previous = previous.getPrevious();
                if (previous == null) throw new IllegalStateException("Missing Duration companion");
                m.instructions.remove(previous);
                m.instructions.insertBefore(call, new FieldInsnNode(GETSTATIC, "kotlin/time/DurationUnit", unit, "Lkotlin/time/DurationUnit;"));
                call.setOpcode(INVOKESTATIC);
                call.owner = "kotlin/time/DurationKt";
                call.name = "toDuration";
                call.desc = "(JLkotlin/time/DurationUnit;)J";
                durations++;
                changed = true;
            }
        }
        if (!changed) return bytes;
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS | ClassWriter.COMPUTE_FRAMES) {
            protected String getCommonSuperClass(String a, String b) { return a.equals(b) ? a : "java/lang/Object"; }
        };
        c.accept(writer);
        System.out.println("Patched " + c.name);
        return writer.toByteArray();
    }

    public static void main(String[] args) throws Exception {
        try (JarFile in = new JarFile(args[0]); JarOutputStream out = new JarOutputStream(Files.newOutputStream(Path.of(args[1])))) {
            for (JarEntry e : Collections.list(in.entries())) {
                byte[] bytes = in.getInputStream(e).readAllBytes();
                if (e.getName().startsWith("com/github/quiltservertools/ledger/") && e.getName().endsWith(".class")) bytes = patch(bytes);
                if (e.getName().equals("fabric.mod.json")) bytes = new String(bytes, java.nio.charset.StandardCharsets.UTF_8).replace("\"version\": \"1.2.8\"", "\"version\": \"1.2.8+gangs.compat.1\"").getBytes(java.nio.charset.StandardCharsets.UTF_8);
                JarEntry entry = new JarEntry(e.getName());
                entry.setTime(0);
                out.putNextEntry(entry);
                out.write(bytes);
                out.closeEntry();
            }
            JarEntry notice = new JarEntry("META-INF/ledger-repair-NOTICE.txt");
            notice.setTime(0);
            out.putNextEntry(notice);
            out.write(("Ledger 1.2.8 compatibility modification, 2026-10-27.\n" +
                "Original: QuiltServerTools/Ledger v1.2.8, LGPL version 3.\n" +
                "Modified DatabaseManager: transactional insert-if-missing world lookup.\n" +
                "Modified two Ledger shutdown coroutine classes: stable DurationKt.toDuration API.\n" +
                "No schema, data migration, configuration, or other behavior changes.\n" +
                "Corresponding source: ledger-v1.2.8-upstream-source.zip plus PatchLedger.java and build.ps1.\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
            out.closeEntry();
        }
        if (worlds != 1 || durations != 2) throw new IllegalStateException("Unexpected patch count: worlds=" + worlds + " durations=" + durations);
        System.out.println("Validated patch counts: worlds=1 durations=2");
    }
}
