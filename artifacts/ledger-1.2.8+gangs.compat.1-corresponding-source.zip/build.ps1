$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
if ((Get-FileHash "$base\ledger-1.2.8.jar" -Algorithm SHA256).Hash -ne 'E8DDBB0FAD40798C72036E7CC0806562D879614C20C18A99ED12E53751F9A88D') {
    throw 'Refusing to patch an unrecognized original Ledger jar'
}
$fixture = Join-Path (Split-Path $base) 'rsw-biome-prod-tests'
$asm = Join-Path $fixture 'libraries\org\ow2\asm'
$patchCp = "$asm\asm\9.10.1\asm-9.10.1.jar;$asm\asm-tree\9.10.1\asm-tree-9.10.1.jar"
& javac -cp $patchCp "$base\PatchLedger.java"
if ($LASTEXITCODE -ne 0) { throw 'Patch compilation failed' }
& java -cp "$base;$patchCp" PatchLedger "$base\ledger-1.2.8.jar" "$base\ledger-1.2.8+gangs.compat.1.jar"
if ($LASTEXITCODE -ne 0) { throw 'Jar patch failed' }
$cp = @(
    "$fixture\.fabric\remappedJars\minecraft-1.20.1-0.19.3\server-intermediary.jar",
    "$base\ledger-1.2.8+gangs.compat.1.jar",
    "$fixture\mods\Multiworld-Fabric-1.20.1.jar"
) + @(Get-ChildItem "$base\api\META-INF\jars" -Filter '*.jar' | ForEach-Object FullName) +
    @(Get-ChildItem "$base\kotlin\META-INF\jars" -Filter '*.jar' | ForEach-Object FullName) +
    @(Get-ChildItem "$fixture\libraries" -Recurse -Filter '*.jar' | ForEach-Object FullName)
New-Item -ItemType Directory -Force "$base\probe-classes" | Out-Null
& javac -proc:none -cp ($cp -join ';') -d "$base\probe-classes" "$base\LedgerProbe.java"
if ($LASTEXITCODE -ne 0) { throw 'Probe compilation failed' }
Copy-Item "$base\probe.fabric.mod.json" "$base\probe-classes\fabric.mod.json"
& jar cf "$base\ledger-repair-probe.jar" -C "$base\probe-classes" .
if ($LASTEXITCODE -ne 0) { throw 'Probe jar failed' }
Get-FileHash "$base\ledger-1.2.8+gangs.compat.1.jar" -Algorithm SHA256
