# v1.1.18 installed server and compatibility fixes

This release publishes the main fixes already built and installed on the
DedicatedMC server. Readback SHA-256 checks verified every listed server jar.
Publishing does not stop, restart, reload or otherwise modify the live server.
The exact deployed binaries are retained, not replaced by new builds.

| Mod | Version | Packwiz side | SHA-256 |
| --- | --- | --- | --- |
| GoldClaim | 1.0.62 | server | `adb06111a1cdcde6961a8e062bd03a74fd9117d6c00d43bacfc0e344952042f9` |
| GangSales | 1.0.3 | server | `e1281a5c5541b0409d2b18babc7fc511f5c44b9e7dc2d5611a2a5266af2cf253` |
| Command Limits | 1.0.1 | server | `871099548cf2117676566173d8e3afbc300ced11daa538b311882dab60a5f5be` |
| Ledger | 1.2.8+gangs.compat.1 | server | `849cbd30aab935b71828c644d074c599aecd7a57c1c4931ff3ee11b5b27416ca` |
| Biolith | 1.0.1-beta.1-endfix-concurrency | both | `6092613e0b6c4fa0df01e850a819e6766fa6cae48e2e3725463a79fb9cbeb497` |
| Rank Badges | 1.0.3 | both | `b30a179d167071292ad2dddd93953a92f9dd2378354770826873e6316d87d79f` |

## Included fixes

- GoldClaim: player-name completion, doubled per-pass sponge absorption,
  world-border checks for shattered dimensional carvers, exact `/tpa`
  destinations, asynchronous RSW arrival preparation, verified-login hub
  transfer ordering, claim protection, ground cleanup and earlier gameplay
  policies in the installed 1.0.62 artifact.
- GangSales: direct LuckPerms API checks instead of failing reflective
  access, explicit permission-check errors, and `/enderchest` alongside `/ec`.
- Command Limits: removes its unconditional `/locate` disabling mixin;
  GoldClaim 1.0.59+ supplies the staff-only gate.
- Ledger: logging transactions register missing worlds and use compatible
  Kotlin duration APIs without resetting database IDs or audit history.
  Previously dropped actions cannot be recovered.
- Biolith: serialized writers publish immutable biome-replacement snapshots;
  readers stay lock-free. The prior End null-tree fix is preserved.
- Rank Badges: Owner, Mod, Gang, Drifters tab order precedes spectator status
  and alphabetical names. Matching hub team definitions are included.

Existing AntiXray, Fiw 2.2.0 and Packet Fixer 3.3.2 metadata remain pinned.
Fiw is installed on both sides; AntiXray and Packet Fixer stay server-only.
Packet sizes remain bounded. Host-specific Fiw exemptions and runtime data
are not published or overwritten.

## Clients

Fully close Minecraft and press Play in the same auto-updating Prism instance.
Packwiz replaces its managed Biolith and Rank Badges jars and verifies their
checksums. No replacement Prism instance is needed. End libraries and Neon
Wall Wonders from the previous releases are retained.

For clients without automatic updates, enable the existing
[pre-launch update hook](README.md), or extract the client update ZIP's
`mods/` files into the existing game's mods directory. Remove old Biolith and
Rank Badges jars first; keep only one enabled version of each.
Do not put the server-only release assets on clients.

## Source and redistribution

GoldClaim, GangSales and Rank Badges source is committed under `sources/`.
GoldClaim uses the exact 1.0.62 build snapshot: the later local-only
pending-login damage protection and its tests are deliberately excluded.
Builds use the included Gradle wrappers and Java 17.
GoldClaim resolves the same pinned Brutal Bosses and Supplementaries jars
from their official download repositories instead of requiring unpublished
local artifact copies. This build-only adjustment does not change its code
or the deployed binary.

Ledger's LGPL corresponding source, original upstream source, patch/build
tools and license are distributed in
`artifacts/ledger-1.2.8+gangs.compat.1-corresponding-source.zip`.
Biolith's complete modified LGPL source is distributed in
`sources/biolith-fabric-1.0.1-beta.1-endfix-concurrency-source.zip`;
the targeted build project is `sources/biolith-concurrency`.
See [artifact attribution](../../ARTIFACTS.md).

Restart installers, unpublished shop/config changes and the local-only
login-damage patch are outside this release. This is not a rebuilt all-in-one
Prism ZIP; existing imports receive the published changes through Packwiz.

## Publication validation

- All 79 GoldClaim unit tests and the Rank Badges rank-order test pass.
- GoldClaim, GangSales, Rank Badges and Biolith compile with Java 17.
- All rebuilt mod classes match the installed artifacts: 125 GoldClaim,
  11 GangSales, two Rank Badges and five patched Biolith classes.
- The pinned GoldClaim development dependency downloads were tested.
- Ledger and both LGPL source archives are readable; embedded licenses
  and attribution are preserved.
- Hosted jar download checksums match the published versions.

## Rollback

Back up the server and stop it before replacing installed server jars.
Restore the previous known-good jars and their corresponding configs rather
than resetting worlds or deleting Ledger's database.
Republish the matching Packwiz metadata before clients relaunch; remove
unmanaged duplicate Biolith/Rank Badges copies manually if necessary.
Do not change the existing startup launcher merely to roll back this
publication. The release does not alter its saved selection.
